import { useState } from 'react';
import { evidenceUtcDay, AuditScope, type Evidence } from '@methane/shared';
import type { MarsObservation } from './mars';

export default function AssessmentScopeEditor({ scope, observations, evidence = [], onChange }: { scope?: AuditScope; observations: Pick<MarsObservation, 'id' | 'date'>[]; evidence?: Evidence[]; onChange: (scope?: AuditScope) => void }) {
  const events = observations.length ? observations : evidence.filter(item => item.kind === 'detection' && item.date).map(item => ({ id: item.id, date: item.date! }));
  const [startDate, setStartDate] = useState(scope?.startDate || '');
  const [endDate, setEndDate] = useState(scope?.endDate || '');
  const [observationId, setObservationId] = useState(scope?.observationId || '');
  const [recipient, setRecipient] = useState(scope?.recipient || '');
  const [error, setError] = useState('');
  function apply() {
    const parsed = AuditScope.safeParse({ startDate, endDate, ...(observationId ? { observationId } : {}), ...(recipient.trim() ? { recipient: recipient.trim() } : {}) });
    if (!parsed.success) { setError('Enter valid dates with the start on or before the end.'); return; }
    const observation = events.find(item => item.id === observationId);
    const day = evidenceUtcDay(observation?.date);
    if (observationId && (!day || day < startDate || day > endDate)) { setError('Choose an observation inside this period.'); return; }
    setError(''); onChange(parsed.data);
  }
  return <section className="case-tool scope-editor" aria-label="Assessment scope">
    <h3>Event and assessment period</h3>
    <p>{scope ? `${scope.startDate} → ${scope.endDate}${scope.observationId ? ` · observation ${scope.observationId}` : ' · whole period'}` : 'Source-level baseline · no event or period bound. Apply a scope before recording a human determination.'}</p>
    <div className="case-tool-grid">
      <label>Period start<input type="date" value={startDate} onChange={event => setStartDate(event.target.value)} /></label>
      <label>Period end<input type="date" value={endDate} onChange={event => setEndDate(event.target.value)} /></label>
      <label>Observation event<select value={observationId} onChange={event => {
        const id = event.target.value; setObservationId(id);
        const observation = events.find(item => item.id === id);
        if (observation && !startDate && !endDate) { const day = evidenceUtcDay(observation.date); if (day) { setStartDate(day); setEndDate(day); } }
      }}><option value="">Whole period · no single observation</option>{events.map(item => <option key={item.id} value={item.id}>{evidenceUtcDay(item.date) || 'Invalid observation date'} · {item.id}</option>)}</select></label>
      <label>Intended notification recipient<input maxLength={160} value={recipient} onChange={event => setRecipient(event.target.value)} placeholder="Required for a notification determination" /></label>
    </div>
    <div className="case-tool-actions"><button type="button" className="outline-btn" onClick={apply}>Apply assessment scope</button><button type="button" className="outline-btn" disabled={!scope} onClick={() => onChange(undefined)}>Use source-level baseline</button></div>
    {error && <p role="alert" className="inline-error">{error}</p>}
    <small>Dates are inclusive UTC calendar days. Timestamps without an offset are treated as UTC. Dates bound the evidence being assessed. Missing records remain unknown. A selected observation does not establish delivery or mitigation.</small>
  </section>;
}
