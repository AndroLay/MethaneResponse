import { expect, test } from 'bun:test';
import { createElement } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { DEMO_SOURCES } from '@methane/shared';
import AssessmentScopeEditor from './AssessmentScopeEditor';

test('scope picker exposes dated DEMO detection references when no observation rows exist', () => {
  const html = renderToStaticMarkup(createElement(AssessmentScopeEditor, { observations: [], evidence: DEMO_SOURCES[0].evidence, onChange: () => {} }));
  expect(html).toContain('value="DEMO-OBS-001"');
  expect(html).toContain('2026-09-01 · DEMO-OBS-001');
});

test('scope picker shows the UTC day instead of the timestamp local day', () => {
  const html = renderToStaticMarkup(createElement(AssessmentScopeEditor, {
    observations: [{ id: 'offset-event', date: '2026-09-30T23:30:00-12:00' }], onChange: () => {},
  }));
  expect(html).toContain('2026-10-01 · offset-event');
  expect(html).toContain('UTC');
});
