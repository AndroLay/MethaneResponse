import { createApp } from './app';
import { createFileAuditStore } from './store';
import { auditStatePath, caseWorkStatePath, FileCaseWorkStore, writerLockPath } from './case-work-file';

if (process.env.METHANE_API_WRITER_LOCK !== writerLockPath()) {
  throw new Error('Start the API through scripts/start-api.ts so its persistent state has one writer.');
}

const store = createFileAuditStore();
const app = createApp(store, undefined, {}, { caseWorkStore: new FileCaseWorkStore(caseWorkStatePath(auditStatePath())) });

export default {
  hostname: process.env.HOST || '0.0.0.0',
  port: Number(process.env.PORT || 3001),
  fetch: (request: Request, server: Bun.Server<unknown>) => app.fetch(request, {
    clientAddress: server.requestIP(request)?.address,
  }),
};
